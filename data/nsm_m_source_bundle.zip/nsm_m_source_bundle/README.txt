New Somatomorphic Matrix Male: selected source figures
=====================================================

Selected figures:
  4%% body fat, FFMI 21
  8%% body fat, FFMI 22.5
 12%% body fat, FFMI 24
 16%% body fat, FFMI 21
 20%% body fat, FFMI 22.5

These are five individual source figures associated with:
Daniel Talbot, Evelyn Smith, John Cass, Scott Griffiths
"Development and Validation of the New Somatomorphic Matrix-Male"
Psychology of Men & Masculinity, 2019. DOI: 10.1037/men0000165

This ZIP does not contain copied PNG bytes. The source host makes the images visible
to the browsing layer but does not make their binary responses available to this
file workspace. download.cmd retrieves the exact author-uploaded PNG files directly
from the source host into an "images" folder.

On Windows:
  1. Extract this ZIP.
  2. Double-click download.cmd.
  3. Open the resulting images folder.

sources.csv contains the verified source pages and direct image URLs.

Note: these five figures do not hold FFMI perfectly constant. The published NSM-M
uses a sparse set of body-fat/FFMI combinations rather than every possible pairing.
