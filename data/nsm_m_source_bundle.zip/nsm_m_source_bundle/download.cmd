@echo off
setlocal
cd /d "%~dp0"
if not exist images mkdir images

echo Downloading exact NSM-M author-uploaded PNGs...

curl.exe -L --fail --retry 2 -o "images\BF4xM21.png" "https://www.researchgate.net/profile/Daniel-Talbot-2/publication/330381996_BF4xM21png/data/5c3d4c55a6fdccd6b5ad9447/BF4xM21.png"
if errorlevel 1 goto :failed
curl.exe -L --fail --retry 2 -o "images\BF8xM22.5.png" "https://www.researchgate.net/profile/Daniel-Talbot-2/publication/330382087_BF8xM225png/data/5c3d4c55a6fdccd6b5ad944b/BF8xM225.png"
if errorlevel 1 goto :failed
curl.exe -L --fail --retry 2 -o "images\BF12xM24.png" "https://www.researchgate.net/profile/Daniel-Talbot-2/publication/330382255_BF12xM24png/data/5c3d4c55299bf12be3c8a38b/BF12xM24.png"
if errorlevel 1 goto :failed
curl.exe -L --fail --retry 2 -o "images\BF16xM21.png" "https://www.researchgate.net/profile/Daniel-Talbot-2/publication/330382001_BF16xM21png/data/5c3d4c55458515a4c726c564/BF16xM21.png"
if errorlevel 1 goto :failed
curl.exe -L --fail --retry 2 -o "images\BF20xM22.5.png" "https://www.researchgate.net/profile/Daniel-Talbot-2/publication/330382091_BF20xM225png/data/5c3d4c55458515a4c726c565/BF20xM225.png"
if errorlevel 1 goto :failed

echo.
echo Done. Images are in the images folder.
pause
exit /b 0

:failed
echo.
echo A ResearchGate download failed. See sources.csv for the exact direct URLs.
pause
exit /b 1
